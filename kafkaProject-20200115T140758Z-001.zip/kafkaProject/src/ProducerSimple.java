import java.util.Properties;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
//import kafka.producer.*;

public class ProducerSimple {
	public static void main (String[] args) {
		
		Properties props= new Properties();
		
		props.put("zk.connect", "localhost:2181");
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("metadata.broker.list", "localhost:9092");
		
		ProducerConfig config = new ProducerConfig(props);
		
		Producer producer= new Producer (config);
		
		for (int i=1;i<10000;i++) {
			
			String msg="Producer send MSG number="+i;
			
			producer.send(new KeyedMessage("testing1",msg));
		}
	}
}