//import java.net.*;
//import java.io.*;
//import kafka.producer.*;
import java.util.Date;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;


public class main {	
	public static void main (String[] args) {
	//public final static int pORT = 4474;
	int pORT = 4474;
	ServerSocket serverSocket = null;
	PrintWriter out = null; // Character output , mesaj gondermek icin

try
{	serverSocket = new ServerSocket(pORT);
	debug("Server started. watting for connection...");
	while (true) 
{
		
try (Socket clientSocket = serverSocket.accept()) 
{
		debug(clientSocket.getInetAddress().getHostName() + " : " + clientSocket.getPort()+ " Connected.");
		debug(clientSocket.getOutputStream() + " : " + clientSocket.getPort());
		debug(clientSocket.getInputStream() + " : " + clientSocket.getPort()); 
		out = new PrintWriter(clientSocket.getOutputStream(), true);
		Date now = new Date();
		out.write(now.toString() +"\r\n");
		out.write("This Massage from server" +"\r\n");
        debug("After I write Message in the client side ");
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        String textFromClient = null;
        String textToClient = null;
        textFromClient = in.readLine(); // read the text from client 
        out.print(textToClient + "\r\n"); // send the response to client
        debug(textFromClient  + "|| client output ...");
       
        KafkaConnection(textFromClient);
        
	 	//out.flush();
     	//out.close();
	 	//clientSocket.close();
		
} catch (IOException e) 
{
	System.err.println(e.getMessage());
	System.exit(1);
}
}
} catch (IOException e) {
	
	System.err.println(e);
}


} // end main
	
private static void debug(String msg ) {
		System.out.println("Client: " + msg);
	}
	
private static void KafkaConnection(String Kafkamsg)
	{
		Properties props= new Properties();
		
		props.put("zk.connect", "localhost:2181");
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("metadata.broker.list", "localhost:9092");
		ProducerConfig config = new ProducerConfig(props);
		Producer producer= new Producer (config);
		producer.send(new KeyedMessage("testing1",Kafkamsg));
	 
	}
}